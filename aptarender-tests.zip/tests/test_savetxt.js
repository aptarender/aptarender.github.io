const {load,ok,done}=require("./harness.js");const fs=require("fs");
const F=process.argv[2];
const [A,B]=fs.readFileSync("s6.txt","utf8").split("\n");
const mgzSeq=fs.readFileSync("mgz.seq","utf8"), mgzDot=fs.readFileSync("mgz.dot","utf8");
const view=`return {strands:strands().map(st=>({seq:st.seq, pt:[...st.pt], nonWC:[...st.nonWC], color:[...st.color],
   circle:Array.from({length:st.n},(_,i)=>st.circleColor[i]||null)})), hp:JSON.stringify(heteroPairs()),
   cx:CM.active?{mode:complexes[CM.idx].mode, segs:cxSegments(complexes[CM.idx]), name:complexes[CM.idx].name}:null,
   circles:$("cCircle").checked}`;
function roundTrip(label, setup){
  console.log(label);
  const P1=load(F); Object.assign(P1.w,{__A:A,__B:B,__ms:mgzSeq,__md:mgzDot,
    __c6:fs.readFileSync("s6_colors.txt","utf8"), __cm:fs.readFileSync("mgz_colors.txt","utf8")});
  P1.run(setup);
  const before=P1.run(view), st=P1.run(`return strandsFileText()`), col=P1.run(`return colorFileText()`);
  ok(st && col, "both text files produced");
  const P2=load(F); P2.w.__st=st; P2.w.__col=col;
  P2.run(`importFasta(__st); applyColorFile(__col);`);
  const after=P2.run(view);
  ok(JSON.stringify(after.strands.map(s=>[s.seq,s.pt,s.nonWC]))===JSON.stringify(before.strands.map(s=>[s.seq,s.pt,s.nonWC])),"sequences + structure (incl. non-WC) identical");
  ok(JSON.stringify(after.cx)===JSON.stringify(before.cx), "complex mode/regions/name identical");
  ok(after.hp===before.hp, "cross-strand pairs identical");
  ok(JSON.stringify(after.strands.map(s=>s.color))===JSON.stringify(before.strands.map(s=>s.color)),"every letter color identical");
  ok(JSON.stringify(after.strands.map(s=>s.circle))===JSON.stringify(before.strands.map(s=>s.circle)),"every circle color identical");
  ok(P1.errors.length+P2.errors.length===0,"no page errors");
  return {st,col};
}
const r6=roundTrip("case 6 — NCB complex", `addDoc(__A,".".repeat(__A.length),"C55 probe"); addDoc(__B,".".repeat(__B.length),"G15 activator");
  complexes.push(newComplex("NCB",docs.length-2,docs.length-1,[{aStart:15,aEnd:44,bStart:0,bEnd:29}],"replace"));
  openComplex(complexes.length-1); applyColorFile(__c6);`);
roundTrip("case 1 — two-region complex", `addDoc("CAGGAACUACUGA",".............","Strand A"); addDoc("UCAGCCUG","........","Strand B");
  complexes.push(newComplex("Fig1A",docs.length-2,docs.length-1,[{aStart:0,aEnd:3,bStart:4,bEnd:7},{aStart:9,aEnd:12,bStart:0,bEnd:3}],"replace"));
  openComplex(complexes.length-1);`);
const rm=roundTrip("case 4 — MgZ single sequence", `$("seq").value=__ms; $("dot").value=__md; renderActiveFromBoxes(); applyColorFile(__cm);`);
console.log("plain FASTA still imports");
const P=load(F); P.w.__f=">x\nGGGAAACCC\n(((...)))\n>y\nACGU\n....\n";
ok(P.run(`const n=docs.length; importFasta(__f); return docs.length-n`)===2,"two plain FASTA records added, no complex");
fs.writeFileSync("ncb_strands.txt",r6.st); fs.writeFileSync("ncb_colors_saved.txt",r6.col); fs.writeFileSync("mgz_colors_saved.txt",rm.col);
done();

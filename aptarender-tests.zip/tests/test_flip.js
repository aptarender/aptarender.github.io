const {load,ok,done}=require("./harness.js");const fs=require("fs");
const [A,B]=fs.readFileSync("s6.txt","utf8").split("\n");
const {w,run,errors}=load(process.argv[2]); w.__A=A;w.__B=B;w.__c=fs.readFileSync("s6_colors.txt","utf8");
run(`addDoc(__A,".".repeat(__A.length),"C55"); addDoc(__B,".".repeat(__B.length),"G15");
  complexes.push(newComplex("NCB",docs.length-2,docs.length-1,[{aStart:15,aEnd:44,bStart:0,bEnd:29}],"replace"));
  openComplex(complexes.length-1); applyColorFile(__c); pushHistory();`);
const snap=()=>run(`return displayPoints(strands()).map(a=>a.map(p=>[p.x,p.y]))`);
const close=(a,b,e=1e-6)=>a.every((s,k)=>s.every((p,i)=>Math.abs(p[0]-b[k][i][0])<e&&Math.abs(p[1]-b[k][i][1])<e));
function mirrored(a,b,axis){ // b is a mirror of a about the common centroid on screen
  const all=x=>x.flat(); const c=p=>p.reduce((s,q)=>[s[0]+q[0]/p.length,s[1]+q[1]/p.length],[0,0]);
  const ca=c(all(a)), cb=c(all(b));
  return a.every((s,k)=>s.every((p,i)=>{ const q=b[k][i];
    return axis==='h' ? Math.abs((p[0]-ca[0])+(q[0]-cb[0]))<1e-6 && Math.abs((p[1]-ca[1])-(q[1]-cb[1]))<1e-6
                      : Math.abs((p[0]-ca[0])-(q[0]-cb[0]))<1e-6 && Math.abs((p[1]-ca[1])+(q[1]-cb[1]))<1e-6; })); }
console.log("whole-drawing flips (nothing selected)");
run(`clearSelection()`);
let s0=snap();
run(`$("flipH").click()`); let s1=snap();
ok(mirrored(s0,s1,'h'),"Flip ↔ mirrors left-right on screen");
ok(run(`return $("rotSelInfo").textContent`).includes("whole drawing"),"tells user it flipped everything");
ok(s1[0][44][0] < s1[0][15][0], "duplex end A45 now left of A16 (duplex left, rings right as in the slide)");
run(`$("flipH").click()`); ok(close(snap(),s0),"flipping twice restores exactly");
run(`$("flipV").click()`); ok(mirrored(s0,snap(),'v'),"Flip ↕ mirrors top-bottom");
run(`undo()`); ok(close(snap(),s0),"Undo reverts a flip");
console.log("with view rotated 37°");
run(`M.rot=37; setRotUI(); render();`); s0=snap();
run(`$("flipH").click()`); ok(mirrored(s0,snap(),'h'),"still mirrors along the SCREEN axis, not a slant");
run(`undo()`);
console.log("selection only");
run(`M.rot=0; setRotUI(); clearSelection(); for(let i=0;i<15;i++) CM.selA.add(i); render();`);
s0=snap();
run(`$("rotSelPivot").value="attach"; $("flipV").click()`); const s2=snap();
ok(s0[1].every((p,i)=>Math.abs(p[0]-s2[1][i][0])<1e-6&&Math.abs(p[1]-s2[1][i][1])<1e-6),"strand B untouched");
ok(s0[0].slice(15).every((p,i)=>Math.abs(p[0]-s2[0][15+i][0])<1e-6),"unselected A bases untouched");
// pivot = attachment base A15 (its neighbour A16 is unselected) -> A15 stays put
ok(Math.abs(s0[0][14][0]-s2[0][14][0])<1e-6&&Math.abs(s0[0][14][1]-s2[0][14][1])<1e-6,"attachment base stays fixed");
ok(Math.abs((s2[0][0][1]-s0[0][14][1])+(s0[0][0][1]-s0[0][14][1]))<1e-6,"selected tail mirrored about the attachment point");
const svg=run(`return buildExportSVG().svg`); ok(/<svg/.test(svg)&&!/NaN/.test(svg),"export is clean (no NaN)");
ok(errors.length===0,"no page errors");
done();

// v2.3.0: Letters+Circles merged into Bases tab, separate circle size (global + per base), (i) tips.
const {load,ok,done}=require("./harness.js");
const F=process.argv[2], BASE=process.argv[3];   // new file, optional pre-change file for comparison
const SEQ="GGGAAACUUCGGUUUCCCAGG", DOT="((((((.(....).))))))..";
const SEQ2=SEQ.slice(0,DOT.length); const D=DOT.slice(0,SEQ2.length);
function draw(P){ P.run(`$("seq").value=${JSON.stringify(SEQ2)}; $("dot").value=${JSON.stringify(D)}; $("render").click();`); }
const circles=svg=>[...svg.matchAll(/<circle cx="([-\d.e]+)" cy="([-\d.e]+)" r="([-\d.e]+)"/g)].map(m=>+m[3]);
const texts=svg=>[...svg.matchAll(/<text[^>]*font-size="([\d.e]+)"[^>]*>([AUGCT])</g)].map(m=>+m[1]);
const lines=svg=>[...svg.matchAll(/<line x1="([-\d.e]+)" y1="([-\d.e]+)" x2="([-\d.e]+)" y2="([-\d.e]+)"/g)].map(m=>m.slice(1).map(Number));

const P=load(F); const {run,errors,w}=P; draw(P);
// ---- tabs / panel ----
const tabs=run(`return [...document.querySelectorAll('#tabs .tab')].map(t=>t.dataset.tab)`);
ok(JSON.stringify(tabs)===JSON.stringify(["input","layout","bases","lines","complex","export"]), "6 tabs, Letters+Circles merged into Bases: "+tabs);
const bh=run(`return [...document.querySelectorAll('[data-pane=bases] > .grp > h2')].map(h=>h.firstChild.textContent.trim())`);
ok(JSON.stringify(bh)===JSON.stringify(["Letters","Circles","Color by base","Selected bases","Color from file"]), "Bases boxes: "+bh);
ok(run(`return !document.querySelector('[data-pane=letters],[data-pane=circles],[data-tab=letters],[data-tab=circles]')`), "old panes gone");
run(`document.querySelector('[data-tab=bases]').click()`);
ok(run(`return $("selbar").style.display`)==='flex', "selection bar shows on the Bases tab");
ok(!/Letters tab|Circles tab|Letters →|Letters\/Circles|Circles-tab/.test(require("fs").readFileSync(F,"utf8")), "no references to the old tab names");

// ---- (i) tips ----
const tipInfo=run(`const o={}; document.querySelectorAll('.pane').forEach(p=>o[p.dataset.pane]=p.querySelectorAll('.ibtn').length); return o`);
ok(tipInfo.input===0 && tipInfo.complex===0 && tipInfo.export===0, "Input / Complex / Export keep inline explanations (no (i)): "+JSON.stringify(tipInfo));
ok(tipInfo.layout>=5 && tipInfo.bases===4 && tipInfo.lines===2, "(i) buttons on Layout/Bases/Lines boxes");
ok(run(`return document.querySelectorAll('#panel .grp > .hint.tip').length`)===0, "every tip moved into a pop-over");
ok(run(`const g=[...document.querySelectorAll('[data-pane=bases] .grp')].find(g=>/Color from file/.test(g.textContent)); return !g.querySelector('.ibtn') && /position \\[base\\] color \\[target\\]/.test(g.querySelector('.fmt').textContent)`), "color-file format stays inline");
// inline explanations are short notes / key lists, not long paragraphs
ok(run(`return [...document.querySelectorAll('[data-pane=input] .note,[data-pane=complex] .note,[data-pane=export] .note,[data-pane=input] .keys,[data-pane=export] .keys')].every(e=>e.textContent.replace(/\\s+/g,' ').trim().length<=200)`), "inline explanations are short (<=200 chars each)");
ok(run(`return /Replace:/.test($("cxModeDesc").textContent)`), "mode description shows Replace by default");
run(`$("cxMode").value='side'; $("cxMode").dispatchEvent(new Event('change'));`);
ok(run(`return /Side-by-side:/.test($("cxModeDesc").textContent) && /first region only/.test($("cxModeDesc").textContent)`), "mode description follows the menu");
run(`$("cxMode").value='replace'; $("cxMode").dispatchEvent(new Event('change'));`);
ok(run(`return [...$("cxMode").options].map(o=>o.textContent).join('|')`)==="Replace|Side-by-side", "short mode labels");
ok(run(`return [...document.querySelectorAll('.ipop')].every(p=>getComputedStyle(p).display==='none')`), "pop-overs closed at start");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[0].click()`);
ok(run(`const p=document.querySelectorAll('[data-pane=bases] .ipop'); return p[0].classList.contains('open') && getComputedStyle(p[0]).display==='block' && /Letter size changes only/.test(p[0].textContent)`), "(i) opens its box's help");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[1].click()`);
ok(run(`const p=document.querySelectorAll('.ipop.open'); return p.length===1 && /independent/.test(p[0].textContent)`), "opening another closes the first");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[1].click()`);
ok(run(`return document.querySelectorAll('.ipop.open').length`)===0, "clicking (i) again closes it");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[2].click(); document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))`);
ok(run(`return document.querySelectorAll('.ipop.open').length`)===0, "Esc closes");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[2].click(); document.body.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}))`);
ok(run(`return document.querySelectorAll('.ipop.open').length`)===0, "click elsewhere closes");
run(`document.querySelectorAll('[data-pane=bases] .ibtn')[2].click(); document.querySelector('[data-tab=lines]').click(); document.querySelector('[data-tab=bases]').click();`);
ok(run(`return document.querySelectorAll('.ipop.open').length`)===0, "tab switch closes");
ok(run(`return document.querySelector('.ibtn').getAttribute('aria-label').startsWith('How to use')`), "(i) has an accessible label");

// ---- global sizes independent ----
run(`$("cCircle").checked=true; render();`);
let s0=run(`return buildExportSVG().svg`);
const r0=circles(s0), t0=texts(s0);
ok(r0.length===SEQ2.length && r0.every(r=>Math.abs(r-13)<1e-9), "default circle radius 13 (26 px diameter)");
ok(t0.every(f=>f===18), "default letter size 18");
run(`$("font").value=30; $("font").dispatchEvent(new Event('input')); $("font").dispatchEvent(new Event('change'));`);
let s1=run(`return buildExportSVG().svg`);
ok(texts(s1).every(f=>f===30) && circles(s1).every(r=>Math.abs(r-13)<1e-9), "Letter size changes letters only");
run(`$("circSize").value=50; $("circSize").dispatchEvent(new Event('input')); $("circSize").dispatchEvent(new Event('change'));`);
let s2=run(`return buildExportSVG().svg`);
ok(texts(s2).every(f=>f===30) && circles(s2).every(r=>Math.abs(r-25)<1e-9), "Circle size changes circles only");
ok(run(`return $("circSizeVal").textContent`)==="50 px", "circle size readout");
// bond ends clear the bigger circle
const L=lines(s2), P2=run(`return displayPoints()[0]`);
const minEnd=Math.min(...L.map(([x1,y1,x2,y2])=>Math.min(...P2.map(p=>Math.min(Math.hypot(x1-p.x,y1-p.y),Math.hypot(x2-p.x,y2-p.y))))));
ok(minEnd>=25*0.62/0.72*0.92-1e-6, "lines stop outside a big circle ("+minEnd.toFixed(2)+")");
run(`$("cCircle").checked=false; render();`);
const L2=lines(run(`return buildExportSVG().svg`));
const minEnd2=Math.min(...L2.map(([x1,y1,x2,y2])=>Math.min(...P2.map(p=>Math.min(Math.hypot(x1-p.x,y1-p.y),Math.hypot(x2-p.x,y2-p.y))))));
ok(Math.abs(minEnd2-30*0.62*0.92)<0.05, "circles hidden: lines follow the letter size only ("+minEnd2.toFixed(2)+")");
run(`$("cCircle").checked=true; render();`);
run(`undo();`);
ok(run(`return $("circSize").value`)==="26" && circles(run(`return buildExportSVG().svg`)).every(r=>Math.abs(r-13)<1e-9), "undo reverts circle size");
run(`redo();`);
ok(run(`return $("circSize").value`)==="50", "redo");

// ---- per-base sizes independent ----
run(`M.selected.clear(); M.selected.add(3); $("selSize").value=200; $("applySize").click();`);
let s3=run(`return buildExportSVG().svg`);
ok(texts(s3)[3]===60 && texts(s3).filter((f,i)=>i!==3).every(f=>f===30), "Letter size on selection: only that letter grows");
ok(circles(s3).every(r=>Math.abs(r-25)<1e-9), "...circles unchanged");
run(`$("selCSize").value=60; $("applyCSize").click();`);
let s4=run(`return buildExportSVG().svg`);
ok(Math.abs(circles(s4)[3]-15)<1e-9 && circles(s4).filter((r,i)=>i!==3).every(r=>Math.abs(r-25)<1e-9), "Circle size on selection: only that circle changes");
ok(texts(s4)[3]===60, "...letter unchanged");
ok(/circle size of 1 base to 60%/.test(run(`return $("sizeInfo").textContent`)), "info line names which size");
run(`$("cCircle").checked=false; M.selected.clear(); M.selected.add(5); $("selCSize").value=150; $("applyCSize").click();`);
ok(run(`return $("cCircle").checked`), "applying a circle size turns circles on");
run(`undo(); undo();`);
ok(run(`return JSON.stringify(M.csize)`)==="{}" && run(`return M.size[3]`)===2, "undo per-base circle size, keeps letter size");
run(`redo(); redo();`);
// menu
run(`openBaseMenu(0,7,100,100); $("bmCSize").value=250; $("bmCSize").dispatchEvent(new Event('input')); $("bmCSize").dispatchEvent(new Event('change'));`);
ok(run(`return M.csize[7]`)===2.5 && run(`return M.size[7]`)===undefined, "menu Circle size sets only the circle");
ok(run(`return /Letter size/.test($("baseMenu").textContent) && /Circle size/.test($("baseMenu").textContent)`), "menu shows both sizes");
run(`$("bmSize").value=120; $("bmSize").dispatchEvent(new Event('input')); $("bmSize").dispatchEvent(new Event('change'));`);
ok(run(`return M.size[7]`)===1.2 && run(`return M.csize[7]`)===2.5, "menu Letter size sets only the letter");
run(`openBaseMenu(0,3,100,100);`);
ok(run(`return $("bmCSize").value`)==="60" && run(`return $("bmSize").value`)==="200", "menu reads back the base's two sizes");
run(`closeBaseMenu();`);
// export contentBox includes a big circle
run(`M.selected.clear(); M.selected.add(0); $("selCSize").value=300; $("applyCSize").click();`);
const vb=run(`const s=buildExportSVG().svg; return s.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number)`);
const p0=run(`return displayPoints()[0][0]`);
ok(p0.x-75>=vb[0] && p0.y-75>=vb[1] && p0.x+75<=vb[0]+vb[2] && p0.y+75<=vb[1]+vb[3], "export frame contains an enlarged circle");

// ---- persist / reload ----
run(`persist();`);
const stored=run(`return localStorage.getItem("aptarender_docs")`);
const Q=load(F,{aptarender_docs:stored});
ok(Q.run(`return $("circSize").value`)==="50" && Q.run(`return $("font").value`)==="30", "global sizes survive reload");
ok(Q.run(`return M.csize[3]`)===0.6 && Q.run(`return M.size[3]`)===2 && Q.run(`return M.csize[0]`)===3, "per-base sizes survive reload");
// reset to default
Q.run(`resetToDefault();`);
ok(Q.run(`return $("circSize").value`)==="26" && Q.run(`return JSON.stringify(M.csize)+JSON.stringify(M.size)`)==="{}{}", "Reset to default clears circle sizes");
Q.run(`undo();`);
ok(Q.run(`return M.csize[3]`)===0.6, "undo reset brings them back");
ok(!Q.errors.length, "no page errors after reload "+Q.errors);

// ---- migration from a pre-split save (one size for both; no circle-size style) ----
const old=JSON.parse(stored);
for(const d of old.docs){ delete d.csize; d.size={"2":2}; if(d.style){ delete d.style.circSize; d.style.font="24"; } }
delete old.style.circSize; old.style.font="24";
const O=load(F,{aptarender_docs:JSON.stringify(old)});
ok(O.run(`return $("circSize").value`)==="35", "old style: circle diameter derived from the letter size (24 x 1.44 = 35)");
ok(O.run(`return M.csize[2]`)===2 && O.run(`return M.size[2]`)===2, "old per-base size applies to both letter and circle");
ok(!O.errors.length, "no page errors on migration "+O.errors);

// ---- compare with the pre-change file: circles hidden = same drawing ----
if(BASE){
  const B=load(BASE); draw(B); draw(P);
  P.run(`resetToDefault(); $("cCircle").checked=false; render();`); B.run(`$("cCircle").checked=false; render();`);
  const a=P.run(`return buildExportSVG().svg`), b=B.run(`return buildExportSVG().svg`);
  const num=x=>x.match(/-?\d+\.?\d*(e-?\d+)?/g).map(Number);
  const na=num(a), nb=num(b);
  ok(na.length===nb.length && na.every((v,i)=>Math.abs(v-nb[i])<1e-6), "default export (no circles) matches the pre-change file");
  P.run(`$("cCircle").checked=true; render();`); B.run(`$("cCircle").checked=true; render();`);
  const ca=P.run(`return buildExportSVG().svg`), cb=B.run(`return buildExportSVG().svg`);
  const xa=num(ca), xb=num(cb);
  ok(xa.length===xb.length && xa.every((v,i)=>Math.abs(v-xb[i])<0.5), "default export with circles within 0.5 px (13 vs 12.96 radius) of the pre-change file");
}
ok(!errors.length, "no page errors "+errors);
done();
